<?php
header("Location: catalog.php");