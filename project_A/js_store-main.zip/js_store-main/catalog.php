<?php
  $title = "Каталог";
  $cssLinks = "
  <link rel=\"stylesheet\" href=\"css/catalog.css\">
  ";
  require_once("components/header.php");
?>
<div class="container">
  <div class="row">
    <div class="col-12">
      <h1>Каталог</h1>
    </div>
  </div>
  <div class="row justify-content-around catalog">

  </div>
</div>
<script src="js/catalog.js"></script>
<? require_once("components/footer.php"); ?>